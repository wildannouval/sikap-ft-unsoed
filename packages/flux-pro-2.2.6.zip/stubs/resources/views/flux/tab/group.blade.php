@pure

<ui-tab-group {{ $attributes->class('block') }} data-flux-tab-group>
    {{ $slot }}
</ui-tab-group>
